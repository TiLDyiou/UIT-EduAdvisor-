import { ArrowTopRightOnSquareIcon } from '@heroicons/react/24/outline';
import type { GetStaticPaths, GetStaticProps } from 'next';
import DefaultErrorPage from 'next/error';
import Link from 'next/link';
import { useRouter } from 'next/router';

import Meta from '@/components/Meta/index';
import {
  getSiteWorkspace,
  getWorkspacePaths,
} from '@/prisma/services/workspace';

type SiteWorkspace = {
  name: string;
  hostname: string;
  domains: Array<{ name: string }>;
};

type SiteProps = {
  workspace: SiteWorkspace | null;
};

const Site = ({ workspace }: SiteProps) => {
  const router = useRouter();

  if (router.isFallback) {
    return <h1>Loading...</h1>;
  }

  return workspace ? (
    <main className="relative flex flex-col items-center justify-center h-screen space-y-10 text-gray-800 bg-gray-50">
      <Meta title={workspace.name} />
      <div className="flex flex-col items-center justify-center p-10 space-y-5 text-center ">
        <h1 className="text-4xl font-bold">
          Welcome to your workspace&apos;s subdomain!
        </h1>
        <h2 className="text-2xl">
          This is the workspace of <strong>{workspace.name}.</strong>
        </h2>
        <p>You can also visit these links:</p>
        <Link
          href={`https://${workspace.hostname}`}
          className="flex space-x-3 text-blue-600 hover:underline"
          target="_blank"
        >
          <span>{`${workspace.hostname}`}</span>
          <ArrowTopRightOnSquareIcon className="w-5 h-5" />
        </Link>
        {workspace.domains.map((domain, index) => (
          <Link
            key={index}
            href={`https://${domain.name}`}
            className="flex space-x-3 text-blue-600 hover:underline"
            target="_blank"
          >
            <span>{domain.name}</span>
            <ArrowTopRightOnSquareIcon className="w-5 h-5" />
          </Link>
        ))}
      </div>
    </main>
  ) : (
    <>
      <Meta title="Not found" noIndex />
      <DefaultErrorPage statusCode={404} />
    </>
  );
};

export const getStaticPaths: GetStaticPaths = async () => {
  const paths = await getWorkspacePaths();
  return {
    paths,
    fallback: true,
  };
};

export const getStaticProps: GetStaticProps<SiteProps> = async ({ params }) => {
  const site = typeof params?.site === 'string' ? params.site : '';

  if (!site || !process.env.APP_URL) {
    return { props: { workspace: null }, revalidate: 10 };
  }

  const siteWorkspace = await getSiteWorkspace(site, site.includes('.'));
  let workspace: SiteWorkspace | null = null;

  if (siteWorkspace) {
    const { host } = new URL(process.env.APP_URL);
    workspace = {
      domains: siteWorkspace.domains,
      name: siteWorkspace.name,
      hostname: `${siteWorkspace.slug}.${host}`,
    };
  }

  return {
    props: { workspace },
    revalidate: 10,
  };
};

export default Site;
