# AGENTS.md

Operating guide for AI coding agents (OpenAI Codex CLI, Aider, Continue, generic LLM agents). The canonical content lives in [`CLAUDE.md`](CLAUDE.md) — this file exists so agents that look for `AGENTS.md` first find their way there.

**Read [`CLAUDE.md`](CLAUDE.md).** It covers:

- What this project is and who its users are
- The current tech stack with versions
- The full file map and where each kind of code belongs
- The conventions we enforce in code review
- The architecture in one paragraph (and the link to the deeper write-up)
- What to do when you're adding common things (API routes, pages, hooks, services)
- What not to do
- The first six files you should read to get oriented

Cursor users: the same content is condensed for the Cursor model in [`.cursorrules`](.cursorrules).
